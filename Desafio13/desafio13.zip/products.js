class Product {

    constructor(title, price, thumbnail, id) {
        this.title = title, 
        this.price = price,
        this.thumbnail = thumbnail,
        this.id = id
    }

}

module.exports = {Product}